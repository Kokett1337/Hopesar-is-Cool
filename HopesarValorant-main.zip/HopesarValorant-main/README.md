# HopesarValorant

Here a dox small dox from naze :/

https://doxbin.org/upload/Naze

Naze and hopesar and retarded pasters not knowing anything how anticheats work.
